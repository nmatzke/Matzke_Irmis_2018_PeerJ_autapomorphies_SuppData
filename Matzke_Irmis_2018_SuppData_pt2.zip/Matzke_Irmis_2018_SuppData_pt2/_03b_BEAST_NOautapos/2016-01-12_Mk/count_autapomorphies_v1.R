
# Load the R libraries for dealing with phylogenies & XML
library(XML)
library(ape)   # for read.tree
library(BioGeoBEARS)	# for sourceall()
#library(gdata) # for read.xls
library(XLConnect)	# for readWorksheetFromFile (seems to work better than read.xls)

#####################################################
# Source BEASTmasteR code via the internet 
# (You could also save the R files locally and source() their locations on your hard disk. 
# This will be especially handy if your internet sucks. I have archived the R code in a 
# dated zipfile, see "Files" at the bottom of the page):
#####################################################

# On Nick's development computer:
sourceall("/GDrive/__github/BEASTmasteR/R/")


wd = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_Mk/"
setwd(wd)

nexfn = "morph_NOautapos_v1.nex"

nex_list = read_nexus_data2(file=nexfn, check_ambig_chars=TRUE, convert_ambiguous_to=NULL, printall="short", convert_ambiguous_to_IUPAC=FALSE) 

nexdf = as.data.frame(x=nex_list, row.names=NULL, stringsAsFactors=FALSE)

numstates_per_char = get_numstates_per_char(nexd=nexdf, ambig_to_remove=c("\\(", "\\)", " ", ","), return_missing_chars="list", printall="short", count_autapomorphies=TRUE)
numstates_per_char

