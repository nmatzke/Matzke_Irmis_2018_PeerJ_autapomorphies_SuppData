# https://gist.github.com/nmatzke/8f80723b6e1fc80ed5ac
#
#
#######################################################
# Calculating the number of unobservable site patterns 
# for the Mk-parsimony-informative ascertainment bias 
# correction
#
# by Nick Matzke, 2015-2016
#
# Free to re-use; we are preparing an ms on this issue,
# please email nick.matzke@anu.edu.au if interested.
# 
#######################################################




# Allman et al. 2010 as Mk pars-inf
# 
# Allman ES, Holder MT, Rhodes JA (2010).
# Estimating trees from filtered data: Identifiability of models 
# for morphological phylogenetics. Journal of Theoretical Biology 
# 263 (1):108-119


source("/drives/GDrive/__github/BEASTmasteR/R/Mk_ParsimonyInformative_v1.R")

res = num_unobservable_patterns_ParsInf(ntaxa=2, nstates=2)
res = num_unobservable_patterns_ParsInf(ntaxa=3, nstates=3)
res = num_unobservable_patterns_ParsInf(ntaxa=4, nstates=4)
res = num_unobservable_patterns_ParsInf(ntaxa=5, nstates=5)


res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=2)
res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=3)
res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=4)
res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=5)


res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=2)
res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=3)
res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=4)
res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=5)




res

sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=5)
sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=5)
sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=1000, nstates=5)
sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=1000, nstates=2)
sum(pattern_counts_table$prod)




# Set WD
wd = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_04_parsimony_informative/"
setwd(wd)

source("/drives/GDrive/__github/BEASTmasteR/R/Mk_ParsimonyInformative_v1.R")
ntaxa_list = c(4,5,10,20,50,100,200,500,1000)
nstates_list = c(2,3,4,5,6)
savefiles=TRUE
printflag=TRUE
ordering="unordered"


res1 = make_table_num_unobservable_patterns(ntaxa_list=ntaxa_list, nstates_list=nstates_list, ordering=ordering, savefiles=savefiles, printflag=printflag)

ordering="ordered"
res2 = make_table_num_unobservable_patterns(ntaxa_list=ntaxa_list, nstates_list=nstates_list, ordering=ordering, savefiles=savefiles, printflag=printflag)

names(res1)
res1$num_patterns_unobservable_matrix_FMT
res2$num_patterns_unobservable_matrix_FMT











#######################################################
# ARCHIVE -- FOR BIOGEOGRAPHY
#######################################################

num_unobservable_patterns_biogeography(ntaxa=10, nstates=NULL, numareas=2, maxareas=NULL)
num_unobservable_patterns_biogeography(ntaxa=10, nstates=NULL, numareas=3, maxareas=NULL)
num_unobservable_patterns_biogeography(ntaxa=10, nstates=NULL, numareas=4, maxareas=NULL)


# Set WD
wd = "/drives/Dropbox/_njm/__packages/BioGeoBEARS_setup/pdfs/DECstar/"
setwd(wd)

# Calculate # of unobservable patterns for a bunch of combinations
max_ntaxa = 20
max_numareas = 9

npatterns_matrix = matrix(data=NA, nrow=max_ntaxa, ncol=max_numareas)

for (i in 1:max_ntaxa)
	{
	for (j in 1:max_numareas)
		{
		ntaxa = i
		numareas = j
		num_unobservable_patterns = num_unobservable_patterns_biogeography(ntaxa=ntaxa, nstates=NULL, numareas=numareas, maxareas=NULL)
		
		npatterns_matrix[i,j] = num_unobservable_patterns
		} # END for (j in 1:max_numareas)
	} # END for (i in 1:max_ntaxa)

# Write to file
npatterns_matrix = as.data.frame(npatterns_matrix)
names(npatterns_matrix) = 1:max_numareas
row.names(npatterns_matrix) = 1:max_ntaxa

xlsfn = "num_unobservable_patterns_BioGeog_matrix_v1.txt"
write.table(x=npatterns_matrix, file=xlsfn, quote=FALSE, sep="\t")
