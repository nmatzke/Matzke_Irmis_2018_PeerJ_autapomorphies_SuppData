


# Allman et al. 2010 as Mk pars-inf
# 
# Allman ES, Holder MT, Rhodes JA (2010).
# Estimating trees from filtered data: Identifiability of models 
# for morphological phylogenetics. Journal of Theoretical Biology 
# 263 (1):108-119


#######################################################
# Permutations
# http://stackoverflow.com/questions/7906332/how-to-calculate-combination-and-permutation-in-r
#######################################################
perm <- function(n, k)
	{
	return(factorial(n) / factorial(n-k))
	}

# Number of unobservable patterns in parsimony-informative data
num_unobservable_patterns_ParsInf <- function(ntaxa, nstates, printflag=TRUE)
	{
	defaults='
	ntaxa=5
	nstates=2
	printflag=TRUE
	'
	
	total_number_of_possible_patterns = nstates^ntaxa
	number_of_unobservable_patterns_given_nstates_observed = 0
	number_of_unobservable_patterns_given_j_states_in_pattern = 0
	number_of_unobservable_patterns_given_j_states_in_pattern_AND_patterns_are_uniform = 0
	
	# Initialize table
	pattern_counts_table = NULL
	
	# First, get the number of states in the patterns
	for (i in nstates:1)
		{
		# Then, make a list of the number of combinations of states that are possible
		number_of_combinations_of_states = choose(n=nstates, k=i)
		
		# For each of these combinations, 1 of the states will be the 
		# dominant state, and (i-1) will be autapomorphic states
		# This can happen nstates i choose 1 ways
		number_of_ways_to_pick_the_dominant_state = choose(n=i, k=1)
		
		# After a dominant state is chosen, there are ntaxa choose (i-1)
		# ways to pick the autapomorphic taxa
		number_of_ways_to_pick_autapomorphic_taxa = choose(n=ntaxa, k=(i-1))
		
		# Given that the autapomorphic taxa have been picked, there are
		# (i-1) PERMUTE (i-1) ways to assign the autapomorphic states
		number_of_ways_to_assign_autapo_states_to_autapo_taxa = perm(n=(i-1), k=(i-1))
		
		product = number_of_combinations_of_states * number_of_ways_to_pick_the_dominant_state * number_of_ways_to_pick_autapomorphic_taxa * number_of_ways_to_assign_autapo_states_to_autapo_taxa
		
		tmprow = c(number_of_combinations_of_states, number_of_ways_to_pick_the_dominant_state, number_of_ways_to_pick_autapomorphic_taxa, number_of_ways_to_assign_autapo_states_to_autapo_taxa, product)
		
		pattern_counts_table = rbind(pattern_counts_table, tmprow)
		}
	
	
	abbreviations = c("ncomb_sts", "npicks_domstate", "npicks_autapo_taxa", "n_assign_autapo_states", "product")
	meaning = c("number of states in the pattern", "number_of_combinations_of_states", "number_of_ways_to_pick_the_dominant_state", "number_of_ways_to_pick_autapomorphic_taxa", "number_of_ways_to_assign_autapo_states_to_autapo_taxa", "number of unobservable patterns given this number of states in the pattern")
	headers_explained = cbind(c("(row names)", abbreviations), meaning)
	headers_explained = as.data.frame(headers_explained, stringsAsFactors=FALSE)
	names(headers_explained) = c("abbreviation", "meaning")
	row.names(headers_explained) = NULL
	
	
	# Label the table
	pattern_counts_table = as.data.frame(pattern_counts_table, stringsAsFactors=FALSE)
	names(pattern_counts_table) = abbreviations
	row.names(pattern_counts_table) = paste0("when_nstates=", nstates:1)
	
	number_of_unobservable_patterns = sum(pattern_counts_table$product)
	
	percentage_of_patterns_unobservable = number_of_unobservable_patterns / total_number_of_possible_patterns * 100
	
	summary_table = matrix(data=c(ntaxa, nstates, number_of_unobservable_patterns, total_number_of_possible_patterns, percentage_of_patterns_unobservable), nrow=1)
	summary_table = as.data.frame(summary_table, stringsAsFactors=FALSE)
	names(summary_table) = c("ntaxa", "nstates", "number_of_unobservable_patterns", "total_number_of_possible_patterns", "percentage_of_patterns_unobservable")
	
	res = NULL
	res$headers_explained = headers_explained
	res$pattern_counts_table = pattern_counts_table
	res$summary_table = summary_table
	
	if (printflag == TRUE)
		{
		require(BioGeoBEARS)
		cat("\n\nTable counting the number of unobservable patterns:\n\n")
		print(conditional_format_table(pattern_counts_table))
		cat("\n\nExplanation of the table headers:\n\n")
		print(headers_explained)
		cat("\n\nSummary of possible and unobservable patterns:\n\n")
		print(conditional_format_table(summary_table))
		}
	
	
	return(res)
	}


res = num_unobservable_patterns_ParsInf(ntaxa=2, nstates=2)
res = num_unobservable_patterns_ParsInf(ntaxa=3, nstates=3)
res = num_unobservable_patterns_ParsInf(ntaxa=4, nstates=4)
res = num_unobservable_patterns_ParsInf(ntaxa=5, nstates=5)


res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=2)
res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=3)
res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=4)
res = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=5)


res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=2)
res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=3)
res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=4)
res = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=5)




res

sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=5)
sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=5)
sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=1000, nstates=5)
sum(pattern_counts_table$prod)

pattern_counts_table = num_unobservable_patterns_ParsInf(ntaxa=1000, nstates=2)
sum(pattern_counts_table$prod)




print(pattern_counts_table)
print(colSums(pattern_counts_table))	
	
	
	
	
	# Error check for <2 states, or for non-integer input
	if ( (nstates < 2) || ( (nstates%%1==0) == FALSE) || (is.numeric(nstates) == FALSE) )
		{
		txt = paste0("ERROR in num_unobservable_patterns_ParsInf(): 'nstates' must be a whole number, and must be > 1. Your nstates input was: '", nstates, "'")
		cat("\n\n")
		cat(txt)
		cat("\n\n")
		stop(txt)
		} # END if ( (nstates < 2) || ( (nstates%%1==0) == FALSE) || (is.numeric(nstates) == FALSE) )
	
	
	for (i in nstates:1)
		{
		# Unobservable patterns assuming all nstates are actually observed
		
		# Number of ways to pick the autapomorphic sites
		number_of_ways_of_picking_the_autapomorphic_positions = choose(n=ntaxa, k=(nstates-1))
		
		# Number of ways to assign the autapomorphies to a particular set of partitions
		number_of_ways_of_assigning_those_nstatesMinus1_autapos_to_each_position = perm(n=(nstates-1), k=(nstates-1))
		npatterns = number_of_ways_of_picking_the_autapomorphic_positions * number_of_ways_of_assigning_those_nstatesMinus1_autapos_to_each_position
		number_of_unobservable_patterns_given_nstates_observed = number_of_unobservable_patterns_given_nstates_observed + npatterns
		
		# But what if fewer than nstates are observed?
		starting_temp_nstates = nstates - 1
		for (j in starting_temp_nstates:1)
			{
			# Number of ways to pick (temp_nstates-1) autapomorphic sites
			temp_nstates = j
			npatterns_w_temp_nstates_fixed = choose(n=ntaxa, k=(temp_nstates-1))
			
			# Number of ways to pick the temp_nstates-1 states to fix
			numways = perm(n=temp_nstates, k=(temp_nstates-1))
			
			npatterns_w_temp_nstates_any = npatterns_w_temp_nstates_fixed * numways
			
			if (npatterns_w_temp_nstates_any == 1)
				{
				number_of_unobservable_patterns_given_j_states_in_pattern_AND_patterns_are_uniform = number_of_unobservable_patterns_given_j_states_in_pattern_AND_patterns_are_uniform + 1
				}
				
			if (npatterns_w_temp_nstates_any > 1)
				{
				number_of_unobservable_patterns_given_j_states_in_pattern = number_of_unobservable_patterns_given_j_states_in_pattern + npatterns_w_temp_nstates_any
				}
				
			if (npatterns_w_temp_nstates_any < 1)
				{
				errortxt = "\n\nERROR in num_unobservable_patterns_ParsInf -- npatterns_w_temp_nstates_any < 1 not allowed.\n\n"
				cat(errortxt)
				stop("STOP error in num_unobservable_patterns_ParsInf")
				}
			
			} # for for (i in temp_nstates:1)
		
		} # END for (i in nstates:1)
	
	if (printflag)
		{
		
		cat("\n\ntotal_number_of_possible_patterns = ", total_number_of_possible_patterns)
		
		cat("\n\nnumber_of_unobservable_patterns_given_nstates_observed = ", number_of_unobservable_patterns_given_nstates_observed)
		cat("\n\nnumber_of_unobservable_patterns_given_j_states_in_pattern = ", number_of_unobservable_patterns_given_j_states_in_pattern)
		cat("\n\nnumber_of_unobservable_patterns_given_j_states_in_pattern_AND_patterns_are_invariant = ", number_of_unobservable_patterns_given_j_states_in_pattern_AND_patterns_are_uniform)
		
		cat("\n\n")
		} # END if (printflag)
	
	# Sum the two sorts of unobservable patterns
	npatterns_unobservable_ParsInf = number_of_unobservable_patterns_given_nstates_observed + number_of_unobservable_patterns_given_j_states_in_pattern + number_of_unobservable_patterns_given_j_states_in_pattern_AND_patterns_are_uniform
	
	return(npatterns_unobservable_ParsInf)
	} # num_unobservable_patterns_ParsInf



npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=2, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=3, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=4, printflag=TRUE)
npatterns_unobservable_ParsInf



npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=2, nstates=2, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=3, nstates=2, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=4, nstates=2, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=2, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=2, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=1000, nstates=2, printflag=TRUE)
npatterns_unobservable_ParsInf




npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=2, nstates=3, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=3, nstates=3, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=4, nstates=3, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=3, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=3, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=1000, nstates=3, printflag=TRUE)
npatterns_unobservable_ParsInf







npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=2, nstates=4, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=3, nstates=4, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=4, nstates=4, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=10, nstates=4, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=100, nstates=4, printflag=TRUE)
npatterns_unobservable_ParsInf

npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=1000, nstates=4, printflag=TRUE)
npatterns_unobservable_ParsInf


# Set WD
wd = "/drives/Dropbox/_njm/__packages/BioGeoBEARS_setup/pdfs/DECstar/"
setwd(wd)

# Calculate # of unobservable patterns for a bunch of combinations
ntaxa_list = c(4, 5, 10, 20, 50, 100, 200, 500, 1000)
nstates_list = c(2,3,4,5,6)

npatterns_unobservable_ParsInf_matrix = matrix(data=NA, nrow=length(ntaxa_list), ncol=length(nstates_list))

for (i in 1:length(ntaxa_list))
	{
	for (j in 1:length(nstates_list))
		{
		ntaxa = ntaxa_list[i]
		nstates = nstates_list[j]
		npatterns_unobservable_ParsInf = num_unobservable_patterns_ParsInf(ntaxa=ntaxa, nstates=nstates, printflag=FALSE)

		npatterns_unobservable_ParsInf_matrix[i,j] = npatterns_unobservable_ParsInf
		} # END for (j in 1:max_numareas)
	} # END for (i in 1:max_ntaxa)

# Write to file
npatterns_unobservable_ParsInf_matrix = as.data.frame(npatterns_unobservable_ParsInf_matrix)
names(npatterns_unobservable_ParsInf_matrix) = nstates_list
row.names(npatterns_unobservable_ParsInf_matrix) = ntaxa_list

xlsfn = "num_unobservable_patterns_ParsInf_matrix_v1.txt"
write.table(x=npatterns_unobservable_ParsInf_matrix, file=xlsfn, quote=FALSE, sep="\t")





# Number of unobservable patterns in biogeography
# (All patterns with null ranges will be excluded)
num_unobservable_patterns_biogeography <- function(ntaxa, nstates=NULL, numareas=NULL, maxareas=NULL)
	{
	# Error check
	if ( all(is.null(nstates), is.null(numareas)) )
		{
		errortxt = "\n\nERROR: in num_unobservable_patterns_biogeography(), 'nstates' and 'numareas'\ncannot both be NULL.\n\n"
		cat(errortxt)
		
		stop("STOP error in num_unobservable_patterns_biogeography.")
		} # END if ( all(is.null(nstates), is.null(numareas)) )
	
	# If calculating the number of areas
	if (is.null(nstates))
		{
		require(cladoRcpp) # for numstates_from_numareas
		
		# If no maxareas, set equal to numareas
		if (is.null(maxareas))
			{
			maxareas = numareas
			} # END if (is.null(maxareas))
		
		nstates = numstates_from_numareas(numareas=numareas, maxareas=maxareas, include_null_range=TRUE)
		} # END if (is.null(nstates))
	
	num_unobservable_patterns_temp = 0
	for (i in 1:ntaxa)
		{
		# Number of possible patterns with first i taxa fixed to "null" range/state
		num_patterns_w_1st_i_taxa_being_null = (nstates-1)^(ntaxa-i)
		
		# Number of ways of picking i taxa to be null
		num_ways_picking_i_taxa = perm(n=ntaxa, k=i)

		npatterns_temp = num_patterns_w_1st_i_taxa_being_null * num_ways_picking_i_taxa
		num_unobservable_patterns_temp = num_unobservable_patterns_temp + npatterns_temp
		} # for (i in 1:ntaxa)
	
	num_unobservable_patterns = num_unobservable_patterns_temp
	
	return(num_unobservable_patterns)
	} # END num_unobservable_patterns_biogeography()



num_unobservable_patterns_biogeography(ntaxa=4, nstates=16, numareas=NULL, maxareas=NULL)

num_unobservable_patterns_biogeography(ntaxa=4, nstates=8, numareas=NULL, maxareas=NULL)

num_unobservable_patterns_biogeography(ntaxa=10, nstates=2, numareas=NULL, maxareas=NULL)




num_unobservable_patterns_biogeography(ntaxa=10, nstates=NULL, numareas=2, maxareas=NULL)
num_unobservable_patterns_biogeography(ntaxa=10, nstates=NULL, numareas=3, maxareas=NULL)
num_unobservable_patterns_biogeography(ntaxa=10, nstates=NULL, numareas=4, maxareas=NULL)


# Set WD
wd = "/drives/Dropbox/_njm/__packages/BioGeoBEARS_setup/pdfs/DECstar/"
setwd(wd)

# Calculate # of unobservable patterns for a bunch of combinations
max_ntaxa = 20
max_numareas = 9

npatterns_matrix = matrix(data=NA, nrow=max_ntaxa, ncol=max_numareas)

for (i in 1:max_ntaxa)
	{
	for (j in 1:max_numareas)
		{
		ntaxa = i
		numareas = j
		num_unobservable_patterns = num_unobservable_patterns_biogeography(ntaxa=ntaxa, nstates=NULL, numareas=numareas, maxareas=NULL)
		
		npatterns_matrix[i,j] = num_unobservable_patterns
		} # END for (j in 1:max_numareas)
	} # END for (i in 1:max_ntaxa)

# Write to file
npatterns_matrix = as.data.frame(npatterns_matrix)
names(npatterns_matrix) = 1:max_numareas
row.names(npatterns_matrix) = 1:max_ntaxa

xlsfn = "num_unobservable_patterns_BioGeog_matrix_v1.txt"
write.table(x=npatterns_matrix, file=xlsfn, quote=FALSE, sep="\t")
