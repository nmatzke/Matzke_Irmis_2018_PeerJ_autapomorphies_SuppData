#######################################################
# Process:
# rate estimates, posterior probabilities, etc.
#######################################################

library(BioGeoBEARS)	# for e.g. conditional_format_cell
sourceall('/drives/GDrive/__github/BEASTmasteR/R/')

wds = c("/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST/2015-12-20_Mk/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST/2015-12-20_Mkv/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST/2016-01-12_Mk_unif/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST/2016-01-12_Mkv_unif/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_Mk/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_Mkv/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_Mk_unif/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_Mkv_unif/")


burnin = 500


pdffn = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics/4runs_unif_v1.pdf"
pdf(file=pdffn, width=8.5, height=8.5)
par(mfrow=c(2,2))

ivals = c(3,4,7,8)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	logfn = "traceLog2.txt"    # Filename of the Beast2 log file
	logdf = read.table(file=logfn, header=TRUE, sep="\t", stringsAsFactors=FALSE)
	logdf = logdf[burnin:nrow(logdf),]


	if (i > 0)
		{
		upperlim = 0.8
		breaksval = 350
		}
	if (i > 2)
		{
		upperlim = 0.8
		breaksval = 300
		}
	if (i > 4)
		{
		upperlim = 8
		breaksval = 50
		}

	
	datavals = logdf$ucldMean_of_shared_clock
	meanval = conditional_format_cell(mean(datavals))
	lower95hpd = conditional_format_cell(quantile(x=datavals, probs=0.025))
	upper95hpd = conditional_format_cell(quantile(x=datavals, probs=0.975))
	titletxt = paste0(run_names[i], "\nclock rate mean, 95% HPD: ", meanval, " (", lower95hpd, ",", upper95hpd, ")")
	
	hist(datavals, breaks=breaksval, main=titletxt, xlim=c(0,upperlim), xlab="clock rate", cex.main=0.9)
	
	abline(v=meanval, col="black", lty="dashed", lwd=2)
	abline(v=lower95hpd, col="gray50", lty="dotted", lwd=2)
	abline(v=upper95hpd, col="gray50", lty="dotted", lwd=2)
	}

head(logdf)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)



pdffn = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics/4runs_normals_v1.pdf"
pdf(file=pdffn, width=8.5, height=8.5)
par(mfrow=c(2,2))

ivals = c(1,2,5,6)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	logfn = "traceLog2.txt"    # Filename of the Beast2 log file
	logdf = read.table(file=logfn, header=TRUE, sep="\t", stringsAsFactors=FALSE)
	logdf = logdf[burnin:nrow(logdf),]


	if (i > 0)
		{
		upperlim = 0.8
		breaksval = 300
		}
	if (i > 1)
		{
		upperlim = 0.8
		breaksval = 500
		}
	if (i > 4)
		{
		upperlim = 8
		breaksval = 50
		}

	
	datavals = logdf$ucldMean_of_shared_clock
	meanval = conditional_format_cell(mean(datavals))
	lower95hpd = conditional_format_cell(quantile(x=datavals, probs=0.025))
	upper95hpd = conditional_format_cell(quantile(x=datavals, probs=0.975))
	titletxt = paste0(run_names[i], "\nclock rate mean, 95% HPD: ", meanval, " (", lower95hpd, ",", upper95hpd, ")")
	
	hist(datavals, breaks=breaksval, main=titletxt, xlim=c(0,upperlim), xlab="clock rate", cex.main=0.9)
	
	abline(v=meanval, col="black", lty="dashed", lwd=2)
	abline(v=lower95hpd, col="gray50", lty="dotted", lwd=2)
	abline(v=upper95hpd, col="gray50", lty="dotted", lwd=2)
	}

head(logdf)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)




pdffn = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics/4runs_unif_posterior_probs_v1.pdf"
pdf(file=pdffn, width=8.5, height=8.5)
par(mfrow=c(2,2))

ivals = c(3,4,7,8)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)
	
	breaksval = 50
	upperlim = 1.0
	
	datavals = nodestats$posterior[nodenums]
	meanval = conditional_format_cell(mean(datavals))
	lower95hpd = conditional_format_cell(quantile(x=datavals, probs=0.025))
	upper95hpd = conditional_format_cell(quantile(x=datavals, probs=0.975))
	titletxt = paste0(run_names[i], "\nPosterior probabilites across branches, mean=", meanval)
	
	hist(datavals, breaks=breaksval, main=titletxt, xlim=c(0,upperlim), xlab="posterior probabilities", cex.main=0.9)
	
	abline(v=meanval, col="black", lty="dashed", lwd=2)
	#abline(v=lower95hpd, col="gray50", lty="dotted", lwd=2)
	#abline(v=upper95hpd, col="gray50", lty="dotted", lwd=2)
	}

head(logdf)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)





node_defs_list = list()
ti = 0

pdffn = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics/8runs_unif_HPDwidths_v1.pdf"
pdf(file=pdffn, width=8.5, height=8.5)
par(mfrow=c(2,2))

ivals = c(3,4,7,8)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)
	
	breaksval = 50
	upperlim = 30
	
	node_defs_list[[(ti=ti+1)]] = beastcon$prt_beast_nodestats$tipnames[nodenums]
	
	datavals = nodestats$height_HPD_width[nodenums]
	meanval = conditional_format_cell(mean(datavals))
	lower95hpd = conditional_format_cell(quantile(x=datavals, probs=0.025))
	upper95hpd = conditional_format_cell(quantile(x=datavals, probs=0.975))
	titletxt = paste0(run_names[i], "\nHPD widths across nodes, mean=", meanval)
	
	hist(datavals, breaks=breaksval, main=titletxt, xlim=c(0,upperlim), xlab="HPD widths", cex.main=0.9)
	
	abline(v=meanval, col="black", lty="dashed", lwd=2)
	#abline(v=lower95hpd, col="gray50", lty="dotted", lwd=2)
	#abline(v=upper95hpd, col="gray50", lty="dotted", lwd=2)
	}

head(logdf)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)


node_defs_list
uniq_node_defs = sort(unique(unlist(node_defs_list)))
TFs = rep(0, times=length(uniq_node_defs))
for (i in 1:length(node_defs_list))
	{
	TF = uniq_node_defs %in% node_defs_list[[i]]
	TFs = TFs + TF
	}
TFs

found_in_all_4 = uniq_node_defs[TFs == 4]
found_in_all_4


# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(3))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(7))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="greater", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))



# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="greater", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))





# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(3))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(4))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="greater", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))









# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(7))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))








# Do Wilcoxon signed-rank test -- paired HPD widths
for (i in c(3))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(7))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_HPD_width[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_HPD_width[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))








# Do Wilcoxon signed-rank test -- paired HPD widths
for (i in c(4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_HPD_width[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_HPD_width[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))











# Do Wilcoxon signed-rank test -- paired HPD widths
for (i in c(3,4,7))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(4,7,8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_HPD_width[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_HPD_width[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], "\n")
		cat("versus\n")
		cat(run_names[j], "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))





# Do Wilcoxon signed-rank test -- paired node ages
for (i in c(3))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(7))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_median[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_median[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], "\n")
		cat("versus\n")
		cat(run_names[j], "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))





# Do Wilcoxon signed-rank test -- paired node ages
for (i in c(4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_median[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_median[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], "\n")
		cat("versus\n")
		cat(run_names[j], "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))



























# Compare rate estimates

# With autapomorphies, Mk model
setwd(wds[3])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldMean_of_shared_clock[seq(500, 2001, 10)]

# Without autapomorphies, Mk model
setwd(wds[7])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldMean_of_shared_clock[seq(500, 2001, 10)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


# With autapomorphies, Mkv model
setwd(wds[4])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldMean_of_shared_clock[500:2001]

# Without autapomorphies, Mkv model
setwd(wds[8])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldMean_of_shared_clock[500:2001]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)




# Compare rate estimates

# With autapomorphies, Mk model
setwd(wds[3])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldMean_of_shared_clock[seq(500, 2001, 10)]

# Without autapomorphies, Mk model
setwd(wds[7])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldMean_of_shared_clock[seq(500, 2001, 10)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


# With autapomorphies, Mkv model
setwd(wds[4])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldMean_of_shared_clock[seq(500, 2001, 100)]

# Without autapomorphies, Mkv model
setwd(wds[8])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldMean_of_shared_clock[seq(500, 2001, 100)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)














# Compare rate estimates

# With autapomorphies, Mk model
setwd(wds[3])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

# Without autapomorphies, Mk model
setwd(wds[7])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


# With autapomorphies, Mkv model
setwd(wds[4])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[500:2001]

# Without autapomorphies, Mkv model
setwd(wds[8])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[500:2001]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)




# Compare rate SD estimates

# With autapomorphies, Mk model
setwd(wds[3])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

# Without autapomorphies, Mk model
setwd(wds[7])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


# With autapomorphies, Mkv model
setwd(wds[4])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[seq(500, 2001, 100)]

# Without autapomorphies, Mkv model
setwd(wds[8])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[seq(500, 2001, 100)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


