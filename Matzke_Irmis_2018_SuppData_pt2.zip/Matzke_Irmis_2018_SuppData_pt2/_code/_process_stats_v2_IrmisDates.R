#######################################################
# Process:
# rate estimates, posterior probabilities, etc.
#######################################################

library(BioGeoBEARS)	# for e.g. conditional_format_cell
sourceall('/drives/GDrive/__github/BEASTmasteR/R/')

graphics_wd = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics/"
setwd(graphics_wd)

wds = c("/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST_IrmisDates/2016-01-12_Mk_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST_IrmisDates/2016-01-12_Mkv_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos_IrmisDates/2016-01-12_Mk_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos_IrmisDates/2016-01-12_Mkv_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos_IrmisDates/2016-01-12_MkParsInf_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST/2016-01-12_Mk_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03_BEAST/2016-01-12_Mkv_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_Mk_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_Mkv_unif_stripFalse/",
"/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_03b_BEAST_NOautapos/2016-01-12_MkParsInf_unif_stripFalse/"
)




run_names = c(
"Autapomorphies included, Mk",
"Autapomorphies included, Mkv",
"Autapomorphies excluded, Mk",
"Autapomorphies excluded, Mkv",
"Autapomorphies excluded, Mk-ParsInf",
"Autapomorphies included, Mk, PBDB dates",
"Autapomorphies included, Mkv, PBDB dates",
"Autapomorphies excluded, Mk, PBDB dates",
"Autapomorphies excluded, Mkv, PBDB dates",
"Autapomorphies excluded, Mk-ParsInf, PBDB dates"
)

burnin = 500



#######################################################
# Plot histograms of posterior of clock rate means
#######################################################

pdffn = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics2_IrmisDates/4runs_unif_v1.pdf"
pdf(file=pdffn, width=8.5, height=8.5)
par(mfrow=c(2,2))

ivals = c(1,2,3,4)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	logfn = "traceLog2.txt"    # Filename of the Beast2 log file
	logdf = read.table(file=logfn, header=TRUE, sep="\t", stringsAsFactors=FALSE)
	logdf = logdf[burnin:nrow(logdf),]


	if (i > 0)
		{
		upperlim = 0.4
		breaksval = 350
		}
	if (i >= 2)
		{
		upperlim = 0.4
		breaksval = 150
		}
	if (i >= 3)
		{
		upperlim = 4
		breaksval = 100
		}

	
	datavals = logdf$ucldMean_of_shared_clock
	meanval = conditional_format_cell(mean(datavals))
	lower95hpd = conditional_format_cell(quantile(x=datavals, probs=0.025))
	upper95hpd = conditional_format_cell(quantile(x=datavals, probs=0.975))
	titletxt = paste0(run_names[i], "\nclock rate mean, 95% HPD: ", meanval, " (", lower95hpd, ",", upper95hpd, ")")
	
	hist(datavals, breaks=breaksval, main=titletxt, xlim=c(0,upperlim), xlab="clock rate", cex.main=0.9)
	
	abline(v=meanval, col="black", lty="dashed", lwd=2)
	abline(v=lower95hpd, col="gray50", lty="dotted", lwd=2)
	abline(v=upper95hpd, col="gray50", lty="dotted", lwd=2)
	}

head(logdf)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)






#######################################################
# Plot histograms of clade posterior probabilities
#######################################################

pdffn = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics2_IrmisDates/4runs_unif_posterior_probs_v1.pdf"
pdf(file=pdffn, width=8.5, height=8.5)
par(mfrow=c(2,2))

ivals = c(1,2,3,4)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)
	
	breaksval = 50
	upperlim = 1.0
	
	datavals = nodestats$posterior[nodenums]
	meanval = conditional_format_cell(mean(datavals))
	lower95hpd = conditional_format_cell(quantile(x=datavals, probs=0.025))
	upper95hpd = conditional_format_cell(quantile(x=datavals, probs=0.975))
	titletxt = paste0(run_names[i], "\nPosterior probabilites across branches, mean=", meanval)
	
	hist(datavals, breaks=breaksval, main=titletxt, xlim=c(0,upperlim), xlab="posterior probabilities", cex.main=0.9)
	
	abline(v=meanval, col="black", lty="dashed", lwd=2)
	#abline(v=lower95hpd, col="gray50", lty="dotted", lwd=2)
	#abline(v=upper95hpd, col="gray50", lty="dotted", lwd=2)
	}

head(logdf)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)





#######################################################
# Plot histograms of HPD widths of node dates
#######################################################

# node_defs_list_4trees is a list of lists
# for each tree, a list of the internal nodes found, defined by their 
# comma-delimited list of tip taxa
node_defs_list_4trees = list()
ti = 0

pdffn = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_graphics2_IrmisDates/8runs_unif_HPDwidths_v1.pdf"
pdf(file=pdffn, width=8.5, height=8.5)
par(mfrow=c(2,2))

ivals = c(1,2,3,4)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)
	
	breaksval = 50
	upperlim = 30
	
	node_defs_list_4trees[[(ti=ti+1)]] = beastcon$prt_beast_nodestats$tipnames[nodenums]
	
	datavals = nodestats$height_HPD_width[nodenums]
	meanval = conditional_format_cell(mean(datavals))
	lower95hpd = conditional_format_cell(quantile(x=datavals, probs=0.025))
	upper95hpd = conditional_format_cell(quantile(x=datavals, probs=0.975))
	titletxt = paste0(run_names[i], "\nHPD widths across nodes, mean=", meanval)
	
	hist(datavals, breaks=breaksval, main=titletxt, xlim=c(0,upperlim), xlab="HPD widths", cex.main=0.9)
	
	abline(v=meanval, col="black", lty="dashed", lwd=2)
	#abline(v=lower95hpd, col="gray50", lty="dotted", lwd=2)
	#abline(v=upper95hpd, col="gray50", lty="dotted", lwd=2)
	}


dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)


node_defs_list_4trees
uniq_node_defs = sort(unique(unlist(node_defs_list_4trees)))
TFs = rep(0, times=length(uniq_node_defs))
for (i in 1:length(node_defs_list_4trees))
	{
	TF = uniq_node_defs %in% node_defs_list_4trees[[i]]
	TFs = TFs + TF
	}
TFs

found_in_all_4 = uniq_node_defs[TFs == 4]
found_in_all_4



#######################################################
# Get node defs list for all 5
#######################################################
node_defs_list_5trees = list()
ti = 0

ivals = c(1,2,3,4,5)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)
	
	breaksval = 50
	upperlim = 30
	
	node_defs_list_5trees[[(ti=ti+1)]] = beastcon$prt_beast_nodestats$tipnames[nodenums]
	}

node_defs_list_5trees
uniq_node_defs = sort(unique(unlist(node_defs_list_5trees)))
TFs = rep(0, times=length(uniq_node_defs))
for (i in 1:length(node_defs_list_5trees))
	{
	TF = uniq_node_defs %in% node_defs_list_5trees[[i]]
	TFs = TFs + TF
	}
TFs

found_in_all_5 = uniq_node_defs[TFs == 5]
found_in_all_5



#######################################################
# Get node defs list for all 10
#######################################################

node_defs_list_10trees = list()
ti = 0

ivals = c(1,2,3,4,5,6,7,8,9,10)
for (i in ivals)
#for (i in 1:1)
	{
	wd = wds[i]
	setwd(wd)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)
	
	breaksval = 50
	upperlim = 30
	
	node_defs_list_10trees[[(ti=ti+1)]] = beastcon$prt_beast_nodestats$tipnames[nodenums]
	}

node_defs_list_10trees
uniq_node_defs = sort(unique(unlist(node_defs_list_10trees)))
TFs = rep(0, times=length(uniq_node_defs))
for (i in 1:length(node_defs_list_10trees))
	{
	TF = uniq_node_defs %in% node_defs_list_10trees[[i]]
	TFs = TFs + TF
	}
TFs

found_in_all_10 = uniq_node_defs[TFs == 10]
found_in_all_10





#######################################################
# Regressions of mean node ages
#######################################################


# http://stackoverflow.com/questions/15271103/how-to-modify-this-correlation-matrix-plot
panel.cor <- function(x, y, digits=2, cex.cor)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(0, 1, 0, 1))
  r <- abs(cor(x, y))
  txt <- format(c(r, 0.123456789), digits=digits)[1]
  test <- cor.test(x,y)
  Signif <- ifelse(round(test$p.value,3)<0.001,"p<0.001",paste("p=",round(test$p.value,3)))  
  text(0.5, 0.25, paste("r=",txt))
  text(.5, .75, Signif)
}

panel.smooth<-function (x, y, col = "blue", bg = NA, pch = 18, 
                        cex = 0.8, col.smooth = "red", span = 2/3, iter = 3, ...) 
{
  points(x, y, pch = pch, col = col, bg = bg, cex = cex)
  ok <- is.finite(x) & is.finite(y)
  if (any(ok)) 
    lines(stats::lowess(x[ok], y[ok], f = span, iter = iter), 
          col = col.smooth, ...)
}

panel.hist <- function(x, ...)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(usr[1:2], 0, 1.5) )
  h <- hist(x, plot = FALSE)
  breaks <- h$breaks; nB <- length(breaks)
  y <- h$counts; y <- y/max(y)
  rect(breaks[-nB], 0, breaks[-1], y, col="cyan", ...)
}




#######################################################
# Assemble table - mean ages of shared nodes
#######################################################
means_table = NULL
run_names2 = run_names

cat("\n\nExtracting shared node age HPDs...\n")
for (i in 1:length(run_names))
	{
	cat(i, " ", sep="")
	
	# Set wd
	wd = wds[i]
	setwd(wd)
	run_name = run_names[i]
	
	# Open tree and get stats
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	
	# Extract ages for shared clades
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)

	clade_defs = beastcon$prt_beast_nodestats$tipnames[nodenums]
	keep_clade_defs_TF = clade_defs %in% found_in_all_10
	clade_defs = clade_defs[keep_clade_defs_TF]

	rows_to_get_dates_from = match(x=found_in_all_10, table=beastcon$prt_beast_nodestats$tipnames)
	
	datavals = nodestats$height[rows_to_get_dates_from]
	meanval = conditional_format_cell(mean(datavals))
	
	# Add to means table
	means_table = cbind(means_table, datavals)
	
	# Put \n in:
	run_names2[i] = gsub(pattern="Autapomorphies", replacement="Autapos", x=run_names[i])
	run_names2[i] = gsub(pattern="PBDB dates", replacement="PBDB", x=run_names2[i])
	run_names2[i] = gsub(pattern=" ", replacement="\n", x=run_names2[i])
	}
	
means_table = adf2(means_table)
names(means_table) = run_names2
means_table




# diag.panel=NULL just plots the column title
pdffn = slashslash(paste0(graphics_wd, "/", "pairs_plot_age_means.pdf"))
pdf(file=pdffn, width=7, height=7)

pairs(means_table, lower.panel=panel.smooth, upper.panel=panel.cor,diag.panel=NULL)

title("Comparison of mean ages for shared nodes", outer=TRUE, line=-1)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)










#######################################################
# Assemble table - HPD widths
#######################################################
means_table = NULL
run_names2 = run_names

cat("\n\nExtracting shared node age HPDs...\n")
for (i in 1:length(run_names))
	{
	cat(i, " ", sep="")
	
	# Set wd
	wd = wds[i]
	setwd(wd)
	run_name = run_names[i]
	
	# Open tree and get stats
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr = beastcon$tr
	nodestats = beastcon$prt_beast_nodestats
	nodestats
	
	
	# Extract ages for shared clades
	tipnums = 1:length(tr$tip.label)
	nodenums = (length(tr$tip.label)+1) : (length(tr$tip.label)+tr$Nnode)

	clade_defs = beastcon$prt_beast_nodestats$tipnames[nodenums]
	keep_clade_defs_TF = clade_defs %in% found_in_all_10
	clade_defs = clade_defs[keep_clade_defs_TF]

	rows_to_get_dates_from = match(x=found_in_all_10, table=beastcon$prt_beast_nodestats$tipnames)
	
	datavals = nodestats$height_HPD_width[rows_to_get_dates_from]
	meanval = conditional_format_cell(mean(datavals))
	
	# Add to means table
	means_table = cbind(means_table, datavals)
	
	# Put \n in:
	run_names2[i] = gsub(pattern="Autapomorphies", replacement="Autapos", x=run_names[i])
	run_names2[i] = gsub(pattern="PBDB dates", replacement="PBDB", x=run_names2[i])
	run_names2[i] = gsub(pattern=" ", replacement="\n", x=run_names2[i])
	}
	
means_table = adf2(means_table)
names(means_table) = run_names2
means_table


# diag.panel=NULL just plots the column title
pdffn = slashslash(paste0(graphics_wd, "/", "pairs_plot_HPD_widths_all10.pdf"))
pdf(file=pdffn, width=7, height=7)

pairs(means_table, lower.panel=panel.smooth, upper.panel=panel.cor,diag.panel=NULL)

title("Comparison of node age HPD widths", outer=TRUE, line=-1)

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)












#######################################################
# Do Wilcoxon signed-rank test -- paired posterior probabilities
#######################################################
for (i in c(1))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(2))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="greater", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))
# Autapomorphies included, Mk, uniform tip priors , mean= 0.9026667 
# versus
# Autapomorphies included, Mkv, uniform tip priors , mean= 0.9 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 13.5, p-value = 0.2949
# alternative hypothesis: true location shift is greater than 0



# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(3))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(4))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="greater", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))

# Autapomorphies excluded, Mk, uniform tip priors , mean= 0.756 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 0.8353333 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 7, p-value = 0.9908
# alternative hypothesis: true location shift is greater than 0






# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(1))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(3))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="greater", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))

# Autapomorphies included, Mk, uniform tip priors , mean= 0.9026667 
# versus
# Autapomorphies excluded, Mk, uniform tip priors , mean= 0.756 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 51, p-value = 0.009491
# alternative hypothesis: true location shift is greater than 0





# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(3))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(1))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="greater", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))

# Autapomorphies excluded, Mk, uniform tip priors , mean= 0.756 
# versus
# Autapomorphies included, Mk, uniform tip priors , mean= 0.9026667 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 4, p-value = 0.9928
# alternative hypothesis: true location shift is greater than 0







# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(2))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(4))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))

# Autapomorphies included, Mkv, uniform tip priors , mean= 0.9 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 0.8353333 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 55.5, p-value = 0.9796
# alternative hypothesis: true location shift is less than 0







# Do Wilcoxon signed-rank test -- paired posterior probabilities
for (i in c(4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(2))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$posterior[TF1][order(tipnames1)]
		datavals2 = nodestats2$posterior[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))

# Autapomorphies excluded, Mkv, uniform tip priors , mean= 0.8353333 
# versus
# Autapomorphies included, Mkv, uniform tip priors , mean= 0.9 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 10.5, p-value = 0.02517
# alternative hypothesis: true location shift is less than 0







# Do Wilcoxon signed-rank test -- paired HPD widths
for (i in c(1,2,3,4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(1,2,3,4))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_HPD_width[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_HPD_width[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))

# Autapomorphies included, Mk, uniform tip priors , mean= 9.195333 
# versus
# Autapomorphies included, Mkv, uniform tip priors , mean= 9.366667 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 41, p-value = 0.2449
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies included, Mk, uniform tip priors , mean= 9.195333 
# versus
# Autapomorphies excluded, Mk, uniform tip priors , mean= 9.944 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 24.5, p-value = 0.02339
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies included, Mk, uniform tip priors , mean= 9.195333 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 9.658667 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 22, p-value = 0.05399
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies included, Mkv, uniform tip priors , mean= 9.366667 
# versus
# Autapomorphies included, Mk, uniform tip priors , mean= 9.195333 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 64, p-value = 0.7744
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies included, Mkv, uniform tip priors , mean= 9.366667 
# versus
# Autapomorphies excluded, Mk, uniform tip priors , mean= 9.944 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 30, p-value = 0.04689
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies included, Mkv, uniform tip priors , mean= 9.366667 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 9.658667 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 32, p-value = 0.1046
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies excluded, Mk, uniform tip priors , mean= 9.944 
# versus
# Autapomorphies included, Mk, uniform tip priors , mean= 9.195333 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 95.5, p-value = 0.9796
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies excluded, Mk, uniform tip priors , mean= 9.944 
# versus
# Autapomorphies included, Mkv, uniform tip priors , mean= 9.366667 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 90, p-value = 0.9584
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies excluded, Mk, uniform tip priors , mean= 9.944 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 9.658667 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 103.5, p-value = 0.9938
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 9.658667 
# versus
# Autapomorphies included, Mk, uniform tip priors , mean= 9.195333 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 69, p-value = 0.9533
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 9.658667 
# versus
# Autapomorphies included, Mkv, uniform tip priors , mean= 9.366667 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 73, p-value = 0.9063
# alternative hypothesis: true location shift is less than 0
# 
# 
# 
# Autapomorphies excluded, Mkv, uniform tip priors , mean= 9.658667 
# versus
# Autapomorphies excluded, Mk, uniform tip priors , mean= 9.944 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 16.5, p-value = 0.007288
# alternative hypothesis: true location shift is less than 0







# Do Wilcoxon signed-rank test -- paired HPD widths
for (i in c(4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_HPD_width[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_HPD_width[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], ", mean=", mean(datavals1), "\n")
		cat("versus\n")
		cat(run_names[j], ", mean=", mean(datavals2), "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))











# Do Wilcoxon signed-rank test -- paired HPD widths
for (i in c(3,4,7))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(4,7,8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_HPD_width[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_HPD_width[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="less", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], "\n")
		cat("versus\n")
		cat(run_names[j], "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))





# Do Wilcoxon signed-rank test -- paired node ages
for (i in c(1,2,3,4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(1,2,3,4))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_median[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_median[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], "\n")
		cat("versus\n")
		cat(run_names[j], "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))



# Autapomorphies included, Mk, uniform tip priors 
# versus
# Autapomorphies included, Mkv, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 14, p-value = 0.01697
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies included, Mk, uniform tip priors 
# versus
# Autapomorphies excluded, Mk, uniform tip priors 
# 
# 	Wilcoxon signed rank test
# 
# data:  datavals1 and datavals2
# V = 43, p-value = 0.3591
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies included, Mk, uniform tip priors 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 68, p-value = 0.67
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies included, Mkv, uniform tip priors 
# versus
# Autapomorphies included, Mk, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 91, p-value = 0.01697
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies included, Mkv, uniform tip priors 
# versus
# Autapomorphies excluded, Mk, uniform tip priors 
# 
# 	Wilcoxon signed rank test
# 
# data:  datavals1 and datavals2
# V = 69, p-value = 0.6387
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies included, Mkv, uniform tip priors 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 79.5, p-value = 0.2803
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies excluded, Mk, uniform tip priors 
# versus
# Autapomorphies included, Mk, uniform tip priors 
# 
# 	Wilcoxon signed rank test
# 
# data:  datavals1 and datavals2
# V = 77, p-value = 0.3591
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies excluded, Mk, uniform tip priors 
# versus
# Autapomorphies included, Mkv, uniform tip priors 
# 
# 	Wilcoxon signed rank test
# 
# data:  datavals1 and datavals2
# V = 51, p-value = 0.6387
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies excluded, Mk, uniform tip priors 
# versus
# Autapomorphies excluded, Mkv, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 81, p-value = 0.07864
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies excluded, Mkv, uniform tip priors 
# versus
# Autapomorphies included, Mk, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 52, p-value = 0.67
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies excluded, Mkv, uniform tip priors 
# versus
# Autapomorphies included, Mkv, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 40.5, p-value = 0.2803
# alternative hypothesis: true location shift is not equal to 0
# 
# 
# 
# Autapomorphies excluded, Mkv, uniform tip priors 
# versus
# Autapomorphies excluded, Mk, uniform tip priors 
# 
# 	Wilcoxon signed rank test with continuity correction
# 
# data:  datavals1 and datavals2
# V = 24, p-value = 0.07864
# alternative hypothesis: true location shift is not equal to 0





# Do Wilcoxon signed-rank test -- paired node ages
for (i in c(4))
	{
	# Load file 1
	wd1 = wds[i]
	setwd(wd1)
	trfn = "treeLog2.mcc"
	digits = 2
	beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
	names(beastcon)
	dim(beastcon$prt_beast_nodestats)
	tr1 = beastcon$tr
	nodestats1 = beastcon$prt_beast_nodestats


	for (j in c(8))
		{
		if (j == i)
			{
			next()
			}
		
		# Load file 2
		wd2 = wds[j]
		setwd(wd2)
		trfn = "treeLog2.mcc"
		digits = 2
		beastcon = read_beast_prt(file=trfn, digits=digits, get_tipnames=TRUE, printflag=FALSE)
		names(beastcon)
		dim(beastcon$prt_beast_nodestats)
		tr2 = beastcon$tr
		nodestats2 = beastcon$prt_beast_nodestats
		
		TF1 = nodestats1$tipnames %in% found_in_all_4
		TF2 = nodestats2$tipnames %in% found_in_all_4
		tipnames1 = nodestats1$tipnames[TF1]
		tipnames2 = nodestats2$tipnames[TF2]
		
		datavals1 = nodestats1$height_median[TF1][order(tipnames1)]
		datavals2 = nodestats2$height_median[TF2][order(tipnames2)]
		
		result = wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=TRUE)
		
		cat("\n\n")
		cat(run_names[i], "\n")
		cat("versus\n")
		cat(run_names[j], "\n")
		print(result)
		} # END for (j in c(4,7,8))
	} # END for (i in c(3,4,7))



























# Compare rate estimates

# With autapomorphies, Mk model
setwd(wds[1])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldMean_of_shared_clock[seq(500, 2001, 10)]

# Without autapomorphies, Mk model
setwd(wds[3])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldMean_of_shared_clock[seq(500, 2001, 10)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)

# > t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  datavals1 and datavals2
# t = -6.5741, df = 161.03, p-value = 6.491e-10
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -1.0773380 -0.5796033
# sample estimates:
#  mean of x  mean of y 
# 0.08895269 0.91742334 
# 
# > t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  log(datavals1) and log(datavals2)
# t = -16.541, df = 231.85, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -2.221778 -1.748822
# sample estimates:
#  mean of x  mean of y 
# -2.9702728 -0.9849727 
# 
# > wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  datavals1 and datavals2
# W = 1419, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0
# 
# > wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  log(datavals1) and log(datavals2)
# W = 1419, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0
# 







# With autapomorphies, Mkv model
setwd(wds[2])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldMean_of_shared_clock[500:2001]

# Without autapomorphies, Mkv model
setwd(wds[4])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldMean_of_shared_clock[500:2001]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)

# > t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  datavals1 and datavals2
# t = -16.551, df = 1504.8, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.5882426 -0.4635875
# sample estimates:
#  mean of x  mean of y 
# 0.03703684 0.56295188 
# 
# > t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  log(datavals1) and log(datavals2)
# t = -56.221, df = 2173.9, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -2.034354 -1.897215
# sample estimates:
# mean of x mean of y 
# -3.523686 -1.557902 
# 
# > wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  datavals1 and datavals2
# W = 99187, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0
# 
# > wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  log(datavals1) and log(datavals2)
# W = 99187, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0
# 

















# Compare rate estimates

# With autapomorphies, Mk model
setwd(wds[1])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

# Without autapomorphies, Mk model
setwd(wds[3])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


# > t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  datavals1 and datavals2
# t = -15.649, df = 254.74, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.9124672 -0.7084831
# sample estimates:
# mean of x mean of y 
#  1.721077  2.531552 
# 
# > t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  log(datavals1) and log(datavals2)
# t = -16.559, df = 294.41, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.4265155 -0.3359017
# sample estimates:
# mean of x mean of y 
# 0.5251932 0.9064018 
# 
# > wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  datavals1 and datavals2
# W = 2023, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0
# 
# > wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  log(datavals1) and log(datavals2)
# W = 2023, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0



# With autapomorphies, Mkv model
setwd(wds[2])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[500:2001]

# Without autapomorphies, Mkv model
setwd(wds[4])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[500:2001]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)

# > t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  datavals1 and datavals2
# t = -41.328, df = 2523.2, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.6591462 -0.5994306
# sample estimates:
# mean of x mean of y 
#  1.711670  2.340958 
# 
# > t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  log(datavals1) and log(datavals2)
# t = -43.201, df = 2920.3, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.3208110 -0.2929537
# sample estimates:
# mean of x mean of y 
# 0.5214752 0.8283576 
# 
# > wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  datavals1 and datavals2
# W = 297740, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0
# 
# > wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  log(datavals1) and log(datavals2)
# W = 297740, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0



# Compare rate SD estimates

# With autapomorphies, Mk model
setwd(wds[1])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

# Without autapomorphies, Mk model
setwd(wds[3])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[seq(500, 2001, 10)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


# > t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  datavals1 and datavals2
# t = -15.649, df = 254.74, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.9124672 -0.7084831
# sample estimates:
# mean of x mean of y 
#  1.721077  2.531552 
# 
# > t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  log(datavals1) and log(datavals2)
# t = -16.559, df = 294.41, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.4265155 -0.3359017
# sample estimates:
# mean of x mean of y 
# 0.5251932 0.9064018 
# 
# > wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  datavals1 and datavals2
# W = 2023, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0
# 
# > wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test with continuity correction
# 
# data:  log(datavals1) and log(datavals2)
# W = 2023, p-value < 2.2e-16
# alternative hypothesis: true location shift is not equal to 0




# With autapomorphies, Mkv model
setwd(wds[2])
log1 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals1 = log1$ucldStdev_of_shared_clock[seq(500, 2001, 100)]

# Without autapomorphies, Mkv model
setwd(wds[4])
log2 = read.table(file="traceLog2.txt", sep="\t", header=TRUE, stringsAsFactors=FALSE)
datavals2 = log2$ucldStdev_of_shared_clock[seq(500, 2001, 100)]

hist(datavals1)
hist(log(datavals1), breaks=50)
hist(log(datavals2), breaks=50)

t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)


# > t.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  datavals1 and datavals2
# t = -4.4965, df = 28.68, p-value = 0.0001047
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -1.1106674 -0.4159477
# sample estimates:
# mean of x mean of y 
#  1.776285  2.539593 
# 
# > t.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Welch Two Sample t-test
# 
# data:  log(datavals1) and log(datavals2)
# t = -4.433, df = 29.36, p-value = 0.0001194
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  -0.5325533 -0.1964134
# sample estimates:
# mean of x mean of y 
# 0.5464130 0.9108963 
# 
# > wilcox.test(x=datavals1, y=datavals2, alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test
# 
# data:  datavals1 and datavals2
# W = 28, p-value = 5.731e-05
# alternative hypothesis: true location shift is not equal to 0
# 
# > wilcox.test(x=log(datavals1), y=log(datavals2), alternative="two.sided", paired=FALSE)
# 
# 	Wilcoxon rank sum test
# 
# data:  log(datavals1) and log(datavals2)
# W = 28, p-value = 5.731e-05
# alternative hypothesis: true location shift is not equal to 0

