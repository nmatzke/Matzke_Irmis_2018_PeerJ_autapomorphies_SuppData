
#######################################################
# Remove autapomorphies from a dataset
#######################################################

library(ape)
library(BioGeoBEARS)
sourceall("/drives/GDrive/__github/BEASTmasteR/R/")
sourceall("/drives/Dropbox/_njm/__packages/TNTR_setup")

wd = "/drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_01_remove_autapos/"
setwd(wd)


#######################################################
# Read data, using BEASTmasteR functions
#######################################################

#######################################################
# These data are from:
# Johannes Muller; Robert R. Reisz (2006). The Phylogeny of Early Eureptiles: 
# Comparing Parsimony and Bayesian Approaches in the Investigation of a Basal 
# Fossil Clade. Systematic Biology,55:3, 503-511.
# http://sysbio.oxfordjournals.org/content/55/3/503.short
# http://dx.doi.org/10.1080/10635150600755396
#######################################################

#######################################################
# Read the NEXUS (Simplified NEXUS!!) morphology file
# into a list of species, each with a list of textual character states
#######################################################
nexfn = "morph_v1.nex"
charslist = read_nexus_data2(file=nexfn, check_ambig_chars=TRUE, convert_ambiguous_to=NULL, printall="short", convert_ambiguous_to_IUPAC=FALSE)

names(charslist)
length(charslist)

# Do summary statistics on the characters list
stats = morphology_matrix_stats(charslist=charslist, charsdf=NULL)
stats

# Save stats
outfn = "morph_completeness_v1.txt"
write.table(x=stats$completeness_df, file=outfn, quote=FALSE, sep="\t")
moref(outfn)

outfn = "morph_matrix_v1.txt"
write.table(x=stats$matrix_stats_df, file=outfn, quote=FALSE, sep="\t")
moref(outfn)



# Convert the characters list to a data.frame of characters
charsdf = as.data.frame(x=charslist, stringsAsFactors=FALSE)
dim(charsdf)
head(charsdf)

# Get the number of states per character
# and a list of autapomorphies
numstates_per_char = get_numstates_per_char(nexd=charsdf, ambig_to_remove=c("\\(", "\\)", " ", ","), return_missing_chars="list", printall="short", count_autapomorphies=TRUE)

# Look at results
names(numstates_per_char)
numstates_per_char
names(numstates_per_char)


# There are no invariant characters
# But, characters 91-132 are autapomorphic
TF = numstates_per_char$char_is_autapomorphic
(1:length(TF))[TF]

#######################################################
# Let's cut the autapomorphic characters and make a new dataset
#######################################################
charsdf2 = charsdf[TF==FALSE,]
charslist2 = as.list(charsdf2)

# Write out to a new NEXUS (Simplified NEXUS!!) file:
outfn = "morph_NOautapos_v1.nex"
write_nexus_data2(x=charslist2, file=outfn, format="STANDARD", datablock=TRUE, interleaved=FALSE, charsperline=NULL, gap=NULL, missing=NULL) 

# Look at the file with the BioGeoBEARS "moref" command
# (works sort of like the UNIX "more" -- prints the file to screen)
moref(outfn)

# Convert to TNT format, using TNTR
tntfn = "morph_NOautapos_v1.tnt"
df2tnt(data_df=charsdf2, nstates="8", tntfn=tntfn, truncate_OTUnames=FALSE, maxlength=32, force_unique=TRUE)

# Look at it
moref(tntfn)

# Get stats on the reduced dataset
stats2 = morphology_matrix_stats(charslist=NULL, charsdf=charsdf2)
stats2

# Save stats
outfn = "morph_NOautapos_completeness_v1.txt"
write.table(x=stats2$completeness_df, file=outfn, quote=FALSE, sep="\t")
moref(outfn)

outfn = "morph_NOautapos_matrix_v1.txt"
write.table(x=stats2$matrix_stats_df, file=outfn, quote=FALSE, sep="\t")
moref(outfn)