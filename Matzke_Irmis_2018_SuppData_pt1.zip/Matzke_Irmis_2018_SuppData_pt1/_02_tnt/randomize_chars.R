#######################################################
# Randomize the tip data 100 times, get null distribution
#######################################################


#######################################################
# Getting some standard Newick/NEXUS trees for reference
#######################################################
library(ape)	# for read/write NEXUS
library(BioGeoBEARS)	# for list2str, moref
library(gdata)	# for trim

source('/drives/Dropbox/_njm/__packages/TNTR_setup/tnt_R_utils_v1.R')
source('/drives/Dropbox/_njm/__packages/BioGeoBEARS_setup/BioGeoBEARS_generics_v1.R')

# On Nick's development computer:
source("/GDrive/__github/BEASTmasteR/R/basics_v1.R")
source("/GDrive/__github/BEASTmasteR/R/gts2012_v1.R")
source("/GDrive/__github/BEASTmasteR/R/make_generic_XML_prior_v1.R")
source("/GDrive/__github/BEASTmasteR/R/make_relativeMutationRate_operator_v1.R")
source("/GDrive/__github/BEASTmasteR/R/master_XML.R")
source("/GDrive/__github/BEASTmasteR/R/parse_clockrow_v1.R")
source("/GDrive/__github/BEASTmasteR/R/parse_clocks_v2.R")
source("/GDrive/__github/BEASTmasteR/R/parse_morph_v1.R")
source("/GDrive/__github/BEASTmasteR/R/parse_node_ages_v1.R")
source("/GDrive/__github/BEASTmasteR/R/parse_run_v1.R")
source("/GDrive/__github/BEASTmasteR/R/parse_OTUs_v1.R")
source("/GDrive/__github/BEASTmasteR/R/parse_sequences_v1.R")
source("/GDrive/__github/BEASTmasteR/R/parse_siteModels_v1.R")
source("/GDrive/__github/BEASTmasteR/R/parse_tree_strat_v1.R")
source("/GDrive/__github/BEASTmasteR/R/read_nexus_data2_v1.R")
source("/GDrive/__github/BEASTmasteR/R/tipdate_gaps_v1.R")
source("/GDrive/__github/BEASTmasteR/R/plotBEAST_v1.R")
source("/GDrive/__github/BEASTmasteR/R/tree_utils_v1.R")


# Set working directory
wd = "/drives/GDrive/__GDrive_projects/2015-08-01_AFA_cladogram/_02_TNT/2015-08-27_runs/allchars_randomize/"
setwd(wd)


#bills_too_short = c("2009_SC_S873", "2009_SC_S873", "2011_FL_SB1854", "2013_AZ_SB1213", "2013_CO_HB130189", "2013_OK_HB1674", "2009_TX_HB4224", "2011_MO_HB195", "2011_KY_HB169")

# Load NEXUS data
nexfn = "morph_v1_noshort.nex"
nexlist = read_nexus_data2(file=nexfn)
nexdf = as.data.frame(nexlist, stringsAsFactors=FALSE, row.names=NULL)
dim(nexdf)

# Randomize data
numsims = 200
fns0 = paste0("z_sims/rand", sprintf("%04.0f", 1:numsims))
fns = paste0(fns0, ".tnt")
head(fns)

numchars = nrow(nexdf)
numtips = ncol(nexdf)
runslow = FALSE
if (runslow == TRUE)
	{
	cat("\nGenerating ", numsims, " randomizations:\n", sep="")
	for (i in 1:numsims)
		{
		cat(i, " ")
		# Randomize each character on the tips
		expr = "sample(x=1:numtips, size=numtips, replace=FALSE)"
		rand_positions = t(replicate(n=numchars, expr=sample(x=1:numtips, size=numtips, replace=FALSE), simplify="array"))
	
		tntdf = nexdf
		for (j in 1:numchars)
			{
			tntdf[j,] = nexdf[j,][rand_positions[j,]]
			}
		
		# Write to TNT
		df2tnt(data_df=tntdf, nstates="8", tntfn=fns[i], truncate_OTUnames=FALSE, maxlength=32, force_unique=TRUE)
		}
	} else {
	cat("\nAlready ran ", numsims, " randomizations:\n", sep="")
	}


runslow = FALSE
if (runslow) {

# Run parsimony on each
treestats_table = NULL
charstats_table = NULL
cat("\nProcessing logfile for TNT parsimony analysis of ", numsims, " randomized datasets.\n")
for (i in 1:numsims)
	{
	cat(i, " ")
	# Temporary TNT script
	tnt_scriptname = "tmpscript.run"
	r = 0
	tnt_runtxt = NULL
	tnt_runtxt[(r=r+1)] = "macro=;"
	tnt_runtxt[(r=r+1)] = paste0("proc ", fns[i], ";")
	tnt_runtxt[(r=r+1)] = "autoMP;"
	tnt_runtxt[(r=r+1)] = "zzz;"
	writeLines(tnt_runtxt, con=tnt_scriptname)

	# Bash script to run TNT 
	# (ONLY WORKS FROM Terminal R, not R.app)
	bash_scriptname = "runtnt.sh"
	cmdstr = paste0("tnt ", tnt_scriptname, ", ;")
	write(x=cmdstr, file=bash_scriptname)
	cmdstr2 = paste0("sh ", bash_scriptname)
	#system(cmdstr2)
	
	cmdstr3 = paste0("tnt ", "proc ", fns[i], ", autoMP, zzz, ;")
	system(cmdstr3)

	#######################################################
	# Read TNT results!
	#######################################################
	# Working directory
	settings = NULL
	settings$wd = "."
	# Filenames
	settings$script_fn = "auto.run"
	settings$MP_topologies_fn = "MP_topologies.tnt"
	settings$indata_fn = "tmpdata.tnt"
	#settings$intrees_fn = "tmptrees.tnt"
	settings$nodenums_fn = "auto_nodenums.tnt"
	settings$branchlengths_fn = "auto_branchlengths.tnt"
	settings$strictcon_fn = "auto_strict_consensus.tnt"

	# Tree with branch lengths (trbl)
	trbl = tntfile2R(settings$branchlengths_fn, brlens=TRUE)

	# Extract stats
	logfn = "auto_logfile.txt"

	# Get tree-wide stats
	treestats = autoget_treestats(logfn)
	treestats

	# Get per-character stats
	charstats = autoget_charstats(logfn)
	charstats
	
	# Save
	treestats_table = rbind(treestats_table, treestats)
	simnum = rep(i, times=numchars)
	charstats = cbind(simnum, charstats)
	charstats_table = rbind(charstats_table, charstats)	
	}


save(treestats_table, file="treestats_table151-350.Rdata")
save(charstats_table, file="charstats_table151-350.Rdata")

write.table(x=treestats_table, file="treestats_table151-350.txt", quote=FALSE, sep="\t", row.names=FALSE)
write.table(x=charstats_table, file="charstats_table151-350.txt", quote=FALSE, sep="\t", row.names=FALSE)
} # END runslow


# Set working directory
wd = "/drives/GDrive/__GDrive_projects/2015-08-01_AFA_cladogram/_02_TNT/2015-08-27_runs/allchars_randomize/"
setwd(wd)

treestats1 = read.table("treestats_table1-50.txt", header=TRUE)
treestats2 = read.table("treestats_table51-100.txt", header=TRUE)
treestats3 = read.table("treestats_table101-150.txt", header=TRUE)
treestats4 = read.table("treestats_table151-350.txt", header=TRUE)
treestats = rbind(treestats1, treestats2, treestats3, treestats4)
head(treestats)
dim(treestats)
charstats1 = read.table("charstats_table1-50.txt", header=TRUE)
charstats2 = read.table("charstats_table51-100.txt", header=TRUE)
charstats3 = read.table("charstats_table101-150.txt", header=TRUE)
charstats4 = read.table("charstats_table151-350.txt", header=TRUE)
charstats = rbind(charstats1, charstats2, charstats3, charstats4)
head(charstats)
dim(charstats)

null_treestats = treestats
null_charstats = charstats
write.table(x=null_treestats, file="null_treestats.txt", quote=FALSE, sep="\t", row.names=FALSE)
write.table(x=null_charstats, file="null_charstats.txt", quote=FALSE, sep="\t", row.names=FALSE)

# Observed MP stats
ob_fn = "/drives/GDrive/__GDrive_projects/2015-08-01_AFA_cladogram/_02_TNT/2015-08-27_runs/allchars/treestats.txt"
obs_treestats = read.table(file=ob_fn, sep="\t", stringsAsFactors=FALSE, header=TRUE)
obs_treestats

pdffn = "observed_vs_randomized_character_stats_allchars_v1.pdf"
pdf(file=pdffn, width=7, height=7)
par(mfrow=c(2,2))

H = hist(treestats$TL, xlim=c(0, 4000), breaks=20, main="Tree Length", xlab="tree length (# steps)", border="gray50", col="grey90")
arrow_x = obs_treestats$TL
arrow_ymax = max(H$counts) * 0.25
arrows(x0=arrow_x, x1=arrow_x, y1=0, y0=arrow_ymax, lwd=3, col="blue")
text(x=arrow_x, y=arrow_ymax*1.25, labels="observed", col="blue", cex=1.4)

H = hist(treestats$CI, xlim=c(0, 1), breaks=20, main="Consistency Index (CI)", xlab="Consistency Index (CI)", border="gray50", col="grey90")
arrow_x = obs_treestats$CI
arrow_ymax = max(H$counts) * 0.25
arrows(x0=arrow_x, x1=arrow_x, y1=0, y0=arrow_ymax, lwd=3, col="blue")
text(x=arrow_x, y=arrow_ymax*1.25, labels="observed", col="blue", cex=1.4)

H = hist(treestats$RI, xlim=c(0, 1), breaks=20, main="Retention Index (RI)", xlab="Retention Index (RI)", border="gray50", col="grey90")
arrow_x = obs_treestats$RI
arrow_ymax = max(H$counts) * 0.25
arrows(x0=arrow_x, x1=arrow_x, y1=0, y0=arrow_ymax, lwd=3, col="blue")
text(x=arrow_x, y=arrow_ymax*1.25, labels="observed", col="blue", cex=1.4)

H = hist(treestats$RCI, xlim=c(0, 1), breaks=20, main="Rescaled Retention Index (CIxRI)", xlab="Rescaled Retention Index (CIxRI)", border="gray50", col="grey90")
arrow_x = obs_treestats$RCI
arrow_ymax = max(H$counts) * 0.25
arrows(x0=arrow_x, x1=arrow_x, y1=0, y0=arrow_ymax, lwd=3, col="blue")
text(x=arrow_x, y=arrow_ymax*1.25, labels="observed", col="blue", cex=1.4)


dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)



#######################################################
# Plot individual character consistencies
#######################################################

# Observed MP stats
ob_fn = "/drives/GDrive/__GDrive_projects/2015-08-01_AFA_cladogram/_02_TNT/2015-08-27_runs/allchars/charstats.txt"
obs_charstats = read.table(file=ob_fn, sep="\t", stringsAsFactors=FALSE, header=TRUE)
obs_charstats

head(charstats)
dim(charstats)

zscore <- function(val, meanval, sdval)
	{
	zscore_val = (val - meanval) / sdval
	return(zscore_val)
	}

calctable_zscores_table <- function(tmptable)
	{
	meanvals = colMeans(tmptable)
	sdvals = apply(X=tmptable, MARGIN=2, FUN=sd)
	
	zscores = NULL
	# Iterate over the columns
	for (j in 1:ncol(tmptable))
		{
		tmp_zscores = zscore(tmptable[,j], meanval=meanvals[j], sdval=sdvals[j])
		zscores = cbind(zscores, tmp_zscores)
		}
	zscores = as.data.frame(zscores, stringsAsFactors=FALSE, row.names=FALSE)
	names(zscores) = names(tmptable)
	return(zscores)
	}





#######################################################
# Observed, versus random, scores by character
#######################################################
pdffn = "observed_vs_randomized_character_stats_bychar_v1.pdf"
pdf(file=pdffn, width=7, height=7)
par(mfrow=c(1,1))

# For each character, calculate the z-score, for steps, homoplasy, CI, RI, CI*RI
numchars = max(charstats$cnum)

# Go through by score type
score_cols = 6:ncol(charstats)
col_names = c("# steps", "homoplasy", "CI", "RI", "CIxRI")
fn_names = c("numsteps", "homoplasy", "CI", "RI", "CIxRI")
name_m = 0
for (m in score_cols)
	{
	name_m = name_m + 1
	zscore_lims_table = NULL

	for (i in 1:numchars)
		{
		TF = charstats$cnum == i
		numsims = sum(TF)
	
		charstats_thischar_allsims = charstats[TF,]
		
		# Add the observed character
		obsrow = as.data.frame(matrix(c(0, obs_charstats[i,]), nrow=1), stringsAsFactors=FALSE)
		names(obsrow) = names(charstats_thischar_allsims)
		obsrow
		charstats_thischar_allsims = unlist_df(rbind(obsrow, charstats_thischar_allsims))
		cls.df(charstats_thischar_allsims)
		
		zscores = calctable_zscores_table(tmptable=charstats_thischar_allsims)
		head(zscores)
	
		# Correct +/- inf
		for (j in score_cols)
			{
			TF = zscores[,m] == Inf
			zscores[,j][TF] = max(zscores[,6][TF==FALSE], na.rm=TRUE)

			TF = zscores[,m] == -Inf
			zscores[,j][TF] = min(zscores[,6][TF==FALSE], na.rm=TRUE)
			}
			
		obsZ = zscores[1,m]
		minZ = min(zscores[,m], na.rm=TRUE)
		maxZ = max(zscores[,m], na.rm=TRUE)
		lower95Z = quantile(zscores[,m], na.rm=TRUE, probs=0.025)
		upper95Z = quantile(zscores[,m], na.rm=TRUE, probs=0.975)
		meanZ = mean(zscores[,m], na.rm=TRUE)
	
		zscore_lims = matrix(data=c(obsZ, meanZ, lower95Z, upper95Z, minZ, maxZ), nrow=1)
		zscore_lims = as.data.frame(zscore_lims, stringsAsFactors=FALSE, row.names=NULL)
		zscore_lims
		names(zscore_lims) = c("obsZ", "meanZ", "lower95Z", "upper95Z", "minZ", "maxZ")
		zscore_lims_table = rbind(zscore_lims_table, zscore_lims)
		}
	head(zscore_lims_table)
	dim(zscore_lims_table)
	
	# Start a plot of the zscores of the null and observed characters
	ymin = min(zscore_lims_table$minZ, na.rm=TRUE)
	ymax = max(zscore_lims_table$maxZ, na.rm=TRUE)
	y_txt = paste0("z-score of ", col_names[name_m])
	plot(x=1:numchars, y=rep(0, times=numchars), pch=".", col="white", ylim=c(ymin,ymax), xlab="character #", ylab=y_txt)
	txt = paste0("Observed and null z-scores for ", col_names[name_m])
	title(txt)

	cat("\nPlot #", m, "/", max(score_cols))
	for (i in 1:numchars)
		{
		# Plot the 95% CI of the zscores (obvious, since they are zscores)
		ymin_theory = -1.96
		ymax_theory = 1.96
	
		# Segments for each min/max range, then 95%, then observed
		segments(x0=i, x1=i, y0=zscore_lims_table$minZ[i], y1=zscore_lims_table$maxZ[i], col="grey90")
		segments(x0=i, x1=i, y0=zscore_lims_table$lower95Z[i], y1=zscore_lims_table$upper95[i], col="grey50")
		points(x=i, y=zscore_lims_table$meanZ[i], col="black", pch=".")
		points(x=i, y=zscore_lims_table$obsZ[i], col="blue", cex=0.5)
		
		# Dotted lines for the theoretical 95% CIs
		abline(h=ymin_theory, lty="dotted", col="black", lwd=1)
		abline(h=ymax_theory, lty="dotted", col="black", lwd=1)
		} # END for (i in 1:numchars)
		
	# Save the z-scores tables...
	outfn = paste0("zscore_lims_table", "_", fn_names[name_m], ".txt")
	cat("\nWriting: '", outfn, "' to disk.", sep="")
	write.table(zscore_lims_table, file=outfn, quote=FALSE, sep="\t")
	
	} # END for (m in score_cols)
	
dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)



#######################################################
# Plot the observed scores
#######################################################
# For each character, calculate the z-score, for steps, homoplasy, CI, RI, CI*RI
numchars = max(charstats$cnum)

pdffn = "observed_stats_by_char.pdf"
pdf(file=pdffn, width=6, height=6)


# Go through by score type
score_cols = 6:ncol(charstats)
col_names = c("# steps", "homoplasy", "CI", "RI", "CIxRI")
name_m = 0
for (m in score_cols)
	{
	name_m = name_m + 1

	# Plot of CI vs
	xvals = 1:numchars
	yvals = obs_charstats[,m-1]
	y_txt = paste0("observed ", col_names[name_m])
	if (m <= 8)
		{
		plot(x=xvals, y=jitter(yvals), pch=1, col="blue", xlab="character #", ylab=y_txt, cex=0.5)
		} else {
		plot(x=xvals, y=jitter(yvals), pch=1, col="blue", xlab="character #", ylab=y_txt, ylim=c(0,1), cex=0.5)
		}
	txt = paste0("Observed ", col_names[name_m], " by character")
	title(txt)
	}

dev.off()
cmdstr = paste0("open ", pdffn)
system(cmdstr)


#######################################################
# Z-score files
#######################################################
wd = "/drives/GDrive/__GDrive_projects/2015-08-01_AFA_cladogram/_02_TNT/2015-08-27_runs/allchars_randomize/"
setwd(wd)
fn1 = "zscore_lims_table_CI.txt"
fn2 = "zscore_lims_table_CIxRI.txt"
fn3 = "zscore_lims_table_homoplasy.txt"
fn4 = "zscore_lims_table_numsteps.txt"
fn5 = "zscore_lims_table_RI.txt"



