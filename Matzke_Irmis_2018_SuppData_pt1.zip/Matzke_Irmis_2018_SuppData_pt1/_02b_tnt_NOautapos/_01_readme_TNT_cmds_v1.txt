#######################################################
# TNT commands in R
#######################################################

# Attempt to change:
#cd /drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_02b_tnt_NOautapos/
#tnt bground proc dataSEA_df.nex, log dataSEA_df.tnt, echo =, echo ], xread *, quote .,, quote proc /.,, quote comments 0, quote .,, echo -, quit, &

# Do basic TNT analysis
# WORKED on 2015-08-27
cd /drives/GDrive/__GDrive_projects/2014-11-21_Randy_Irmis_autapomorphies/_02b_tnt_NOautapos/
tnt proc morph_NOautapos_v1.tnt, forceConstraints, auto, zzz, ; open auto_logfile.txt;
Rscript _02_read_autorun_v1.R
Rscript _03_MPtipheight_vs_time.R
Rscript _04_simple_plot_MP_allchars.R

